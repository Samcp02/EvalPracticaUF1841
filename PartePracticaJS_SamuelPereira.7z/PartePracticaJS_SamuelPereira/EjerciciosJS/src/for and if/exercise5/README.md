# Conditional counter

Completa [index.js](index.js) para contar e imprimir la cantidad de veces que el número 5 aparece en el array ```numbers```.

## if
```JavaScript
const number1 = 5;
const number2 = 6
if (number1 > number2) {
    console.log("Number1 is grater then number2")
}
```