// Put your code here

for (let outer = 1; outer < 10 ; outer++) {
    for (let inner = 1; inner < 10; inner++ ){
        console.log(`${outer} x ${inner} = ` + outer * inner)}
}