/*const numbers = [22,1,4,3,5,7,8,9,12,11];
const odd = [];
const even = []

for (let item of numbers) {
    console.log("item:", item);

    // Put your code here
    if (item%2 === 0) {
        even.push(item);
    } else {
        odd.push(item);
    }

}

console.log("odd:", odd);
console.log("even:", even);
*/



/* ejercicio 
const valores = {primero:33, segundo: 21, tercero:48}
const posicion = 'segundo'
const x = valores.segundo === valores[posicion]
console.log(x)
*/

//ejercicio 13
let x = 0
for(let y = 0; y < 3; y++){
    x++
}
console.log(y)