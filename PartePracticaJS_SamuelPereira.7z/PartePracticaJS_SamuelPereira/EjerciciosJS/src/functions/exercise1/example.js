function suma (a,b) {
    const total = a + b;
    return total
}

const tot1 = suma(5,9);
const tot2 = suma(1,13);
const tot3 = suma(9,2);

console.log(tot1, tot2, tot3)