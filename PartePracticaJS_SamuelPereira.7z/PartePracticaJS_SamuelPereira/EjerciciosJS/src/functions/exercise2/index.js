const number = 0;


function plusOne(number) {
    number = number + 1;
    return console.log(number);
    
}

console.log(plusOne(2));