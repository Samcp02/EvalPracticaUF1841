# One function each function.

Tienes una funcion para buscar el menor número en un rango de un array y otra para intercambiar la posición de dos números en un array. Esto pide a gritos ser empleado para ordenar rangos.

Hazlo en el fichero [index.js](index.js).
* Pega en el las funciones de los ejercicios correspondientes y añade el código necesario.
* Piensa que para ordenar un array te interesa más conocer el índice de la posición en la que se encuentra el número más pequeño que el valor del número en si.