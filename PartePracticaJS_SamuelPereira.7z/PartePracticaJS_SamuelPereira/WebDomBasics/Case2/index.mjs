let button = document.querySelector('button');

button.addEventListener('click', multiplicarX2)

function multiplicarX2 () {
    console.log('Prueba')
}